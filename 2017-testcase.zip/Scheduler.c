#include "Init.h"
#include "Thread.h"
#include "Scheduler.h"


int		RunScheduler( void )
{
}


void		_ContextSwitch(int curpid, int tpid)
{
}

