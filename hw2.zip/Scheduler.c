#include "Init.h"
#include "Thread.h"
#include "Scheduler.h"


int		RunScheduler( void )
{
	
}


void            __ContextSwitch(Thread pCurThread, Thread* pNewThread)
{
}

